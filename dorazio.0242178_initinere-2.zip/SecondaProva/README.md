# IA_2017_SecondaProva
Seconda prova pratica per l'esame di Ingegneria degli Algoritmi
